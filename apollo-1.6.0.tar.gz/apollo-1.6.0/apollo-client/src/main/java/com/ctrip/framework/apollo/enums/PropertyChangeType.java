package com.ctrip.framework.apollo.enums;


/**
 * @author Jason Song(song_s@ctrip.com)
 */
public enum PropertyChangeType {
  ADDED, MODIFIED, DELETED
}
