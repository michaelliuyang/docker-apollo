DELETE FROM Release;
DELETE FROM Namespace;
DELETE FROM AppNamespace;
DELETE FROM Cluster;
DELETE FROM App;
DELETE FROM ReleaseMessage;
DELETE FROM GrayReleaseRule;


